import Link from "next/link"
import Image from "next/image"
import { ChevronRight } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-[#f5f2e8]">
      <div className="relative h-[60vh] md:h-[70vh] w-full">
        <Image
          src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
          alt="Historic Fort Vancouver"
          fill
          className="object-cover brightness-75"
          priority
        />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-white mb-4 tracking-tight">Fort Vancouver</h1>
          <p className="text-xl md:text-2xl font-serif text-white mb-8 max-w-3xl">More Than a Fur Trading Post</p>
          <Link
            href="#introduction"
            className="bg-[#5d4037] hover:bg-[#3e2723] text-white font-serif py-2 px-6 rounded-md transition-colors flex items-center"
          >
            Explore History <ChevronRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>

      <main className="container mx-auto px-4 py-12">
        <section id="introduction" className="max-w-4xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
            Introduction
          </h2>
          <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
            <p>
              The Hudson's Bay Company established Fort Vancouver in 1824 and soon expanded beyond its use as a fur
              trading post to become the primary Pacific Northwest cultural, economic, and political hub during pivotal
              times of colonial expansion and change. Fort Vancouver is located in modern-day Washington State in the
              city of Vancouver, the oldest continuously inhabited white settlement in the state.
            </p>
            <p>
              While the fur trade played an important role in its early years Fort Vancouver evolved into a strong hub
              for supply, industry, and agriculture that supported large settlement populations around the area,
              including other neighboring forts. Additionally, the fort served as a place for cultural exchange between
              indigenous peoples, Métis workers, British colonists, and eventually American settlers, creating
              relationships that intricately formed the social fabric of the area.
            </p>
            <p>
              Beyond its impact on culture and the economy, Fort Vancouver played a crucial role in the shifting balance
              of colonial powers. As British control gave way to American expansion after the Oregon Treaty of 1846. The
              fort played an impactful part in reshaping borders, systems of government, and settlement patterns,
              eventually transitioning from a British trading post to a U.S. military reservation in 1848.
            </p>
            <p>
              This project examines the broader historical significance of Fort Vancouver, highlighting its
              contributions to regional development and its influence on colonial and political structure dynamics,
              including its lasting imprint on the people and places of the Pacific Northwest.
            </p>
          </div>
        </section>

        <section className="max-w-4xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
            Explore Fort Vancouver's History
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Link href="/economic-development" className="group">
              <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                <div className="h-56 relative">
                  <Image
                    src="https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2074&q=80"
                    alt="Economic Development"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-xl font-serif font-bold text-[#5d4037] mb-2">Economic Development</h3>
                  <p className="text-[#33272a]">
                    Explore how Fort Vancouver evolved into a farming center and supply hub for the Pacific Northwest.
                  </p>
                  <div className="mt-4 text-[#5d4037] font-medium flex items-center">
                    Learn more <ChevronRight className="ml-1 h-4 w-4" />
                  </div>
                </div>
              </div>
            </Link>

            <Link href="/cultural-exchange" className="group">
              <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                <div className="h-56 relative">
                  <Image
                    src="https://images.unsplash.com/photo-1544027993-37dbfe43562a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                    alt="Cultural Exchange"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-xl font-serif font-bold text-[#5d4037] mb-2">Cultural Exchange</h3>
                  <p className="text-[#33272a]">
                    Discover the multicultural life at the fort and interactions with Indigenous peoples.
                  </p>
                  <div className="mt-4 text-[#5d4037] font-medium flex items-center">
                    Learn more <ChevronRight className="ml-1 h-4 w-4" />
                  </div>
                </div>
              </div>
            </Link>

            <Link href="/colonialism-politics" className="group">
              <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                <div className="h-56 relative">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-AzfkYDmeRcNO5zs8FjOWZFYDp3Akgw.png"
                    alt="Colonialism & Politics"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-xl font-serif font-bold text-[#5d4037] mb-2">Colonialism & Politics</h3>
                  <p className="text-[#33272a]">
                    Examine the fort's role in British colonial control and its transition to U.S. hands.
                  </p>
                  <div className="mt-4 text-[#5d4037] font-medium flex items-center">
                    Learn more <ChevronRight className="ml-1 h-4 w-4" />
                  </div>
                </div>
              </div>
            </Link>

            <Link href="/legacy-settlement" className="group">
              <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                <div className="h-56 relative">
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pKzb53b79yO0BoPsLVJxqKNqziYYFZ.png"
                    alt="Legacy & Settlement"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-xl font-serif font-bold text-[#5d4037] mb-2">Legacy & Settlement</h3>
                  <p className="text-[#33272a]">
                    See how Fort Vancouver influenced early American settlement and regional development.
                  </p>
                  <div className="mt-4 text-[#5d4037] font-medium flex items-center">
                    Learn more <ChevronRight className="ml-1 h-4 w-4" />
                  </div>
                </div>
              </div>
            </Link>
          </div>
        </section>

        <section className="max-w-4xl mx-auto mb-16">
          <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg p-6 shadow-md">
            <h2 className="text-2xl font-serif font-bold text-[#3e2723] mb-4">
              Creative Feature: A Voice from the Past
            </h2>
            <Link
              href="/creative-feature"
              className="text-[#5d4037] hover:text-[#3e2723] transition-colors flex items-center font-serif italic"
            >
              Read a fictional diary entry from a Fort Vancouver resident
              <ChevronRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </section>
      </main>

      <footer className="bg-[#3e2723] text-[#e8e1d1] py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-serif font-bold">Fort Vancouver: More Than a Fur Trading Post</h2>
              <p className="text-sm mt-1">A historical presentation website</p>
            </div>
            <nav>
              <ul className="flex flex-wrap justify-center gap-4">
                <li>
                  <Link href="/" className="hover:underline">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/economic-development" className="hover:underline">
                    Economic Development
                  </Link>
                </li>
                <li>
                  <Link href="/cultural-exchange" className="hover:underline">
                    Cultural Exchange
                  </Link>
                </li>
                <li>
                  <Link href="/colonialism-politics" className="hover:underline">
                    Colonialism & Politics
                  </Link>
                </li>
                <li>
                  <Link href="/legacy-settlement" className="hover:underline">
                    Legacy & Settlement
                  </Link>
                </li>
                <li>
                  <Link href="/sources" className="hover:underline">
                    Sources
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
          <div className="mt-6 text-center text-sm">
            <p>© {new Date().getFullYear()} Historical Presentation Project</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
