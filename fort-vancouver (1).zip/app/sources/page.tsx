import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function Sources() {
  return (
    <div className="min-h-screen bg-[#f5f2e8]">
      <header className="bg-[#3e2723] py-12 text-[#e8e1d1]">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-5xl font-serif font-bold text-center">Sources</h1>
          <p className="text-lg md:text-xl font-serif text-center mt-2 max-w-3xl mx-auto">
            Academic References and Further Reading
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <Link href="/" className="inline-flex items-center text-[#5d4037] hover:text-[#3e2723] mb-8 transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        <div className="max-w-4xl mx-auto">
          <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg p-6 shadow-md mb-8">
            <h2 className="text-2xl font-serif font-bold text-[#3e2723] mb-4">Primary Sources</h2>
            <div className="space-y-4 font-serif text-[#33272a]">
              <div className="pl-8 -indent-8">
                <p>
                  McLoughlin, John. <em>Letters of Dr. John McLoughlin, Written at Fort Vancouver 1829-1832</em>. Edited
                  by Burt Brown Barker, Binfords & Mort for the Oregon Historical Society, 1948.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Hudson's Bay Company Archives. <em>Fort Vancouver Correspondence Outward, 1825-1860</em>. Provincial
                  Archives of Manitoba, Winnipeg.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg p-6 shadow-md mb-8">
            <h2 className="text-2xl font-serif font-bold text-[#3e2723] mb-4">Books and Monographs</h2>
            <div className="space-y-4 font-serif text-[#33272a]">
              <div className="pl-8 -indent-8">
                <p>
                  Barman, Jean. <em>The West Beyond the West: A History of British Columbia</em>. 3rd ed. University of
                  Toronto Press, 2007.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Gibson, James R.{" "}
                  <em>Farming the Frontier: The Agricultural Opening of the Oregon Country, 1786-1846</em>. University
                  of Washington Press, 1985.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Hussey, John A. <em>The History of Fort Vancouver and Its Physical Structure</em>. Washington State
                  Historical Society, 1957.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Mackie, Richard Somerset.{" "}
                  <em>Trading Beyond the Mountains: The British Fur Trade on the Pacific, 1793-1843</em>. University of
                  British Columbia Press, 1997.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Morrison, Dorothy Nafus. <em>Outpost: John McLoughlin and the Far Northwest</em>. Oregon Historical
                  Society Press, 1999.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Rich, E.E. <em>The History of the Hudson's Bay Company, 1670-1870</em>. 2 vols. Hudson's Bay Record
                  Society, 1958-1959.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg p-6 shadow-md mb-8">
            <h2 className="text-2xl font-serif font-bold text-[#3e2723] mb-4">Journal Articles</h2>
            <div className="space-y-4 font-serif text-[#33272a]">
              <div className="pl-8 -indent-8">
                <p>
                  Bunting, Robert. "The Pacific Raincoast: Environment and Culture in an American Eden, 1778-1900."{" "}
                  <em>Environmental History</em> 6, no. 2 (2001): 131-153.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Keddie, Grant R. "The Fort Victoria Treaties." <em>BC Studies</em> 57 (1983): 99-132.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Mitchell, Donald. "Prehistory of the Coasts of Southern British Columbia and Northern Washington."{" "}
                  <em>Handbook of North American Indians</em>, vol. 7. Smithsonian Institution, 1990.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Vogt, Tom. "History and agriculture team up: Visitors to Fort Vancouver site see horses, mules work up
                  the ground." <em>McClatchy - Tribune Business News</em>, 2009.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Wilson, Bruce A. "The Struggle for Wealth and Power at Fort Niagara, 1775-1783."{" "}
                  <em>Ontario History</em> 68, no. 3 (1976): 137-154.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg p-6 shadow-md mb-8">
            <h2 className="text-2xl font-serif font-bold text-[#3e2723] mb-4">Reference Works</h2>
            <div className="space-y-4 font-serif text-[#33272a]">
              <div className="pl-8 -indent-8">
                <p>
                  Encyclopædia Britannica. "Hudson's Bay Company." <em>Encyclopædia Britannica</em>, Encyclopædia
                  Britannica, Inc., 2025, https://www.britannica.com/money/Hudsons-Bay-Company.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Encyclopædia Britannica. "Vancouver." <em>Encyclopædia Britannica</em>, Encyclopædia Britannica, Inc.,
                  2025, https://www.britannica.com/place/Vancouver-Washington.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  National Park Service. "Fort Vancouver National Historic Site."{" "}
                  <em>U.S. Department of the Interior</em>, 2024, https://www.nps.gov/fova/index.htm.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg p-6 shadow-md mb-8">
            <h2 className="text-2xl font-serif font-bold text-[#3e2723] mb-4">Archival Collections</h2>
            <div className="space-y-4 font-serif text-[#33272a]">
              <div className="pl-8 -indent-8">
                <p>
                  Fort Vancouver National Historic Site Archives. Archaeological and Historical Collections. Vancouver,
                  Washington.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>
                  Oregon Historical Society Research Library. Fort Vancouver and Hudson's Bay Company Collections.
                  Portland, Oregon.
                </p>
              </div>
              <div className="pl-8 -indent-8">
                <p>Washington State Historical Society. Pacific Northwest History Collections. Tacoma, Washington.</p>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center mt-12 pt-6 border-t border-[#c9bda0]">
            <Link
              href="/creative-feature"
              className="text-[#5d4037] hover:text-[#3e2723] transition-colors flex items-center"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous: Creative Feature
            </Link>
            <Link
              href="/"
              className="bg-[#5d4037] hover:bg-[#3e2723] text-white font-serif py-2 px-4 rounded-md transition-colors"
            >
              Return to Home
            </Link>
          </div>
        </div>
      </main>

      <footer className="bg-[#3e2723] text-[#e8e1d1] py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-serif font-bold">Fort Vancouver: More Than a Fur Trading Post</h2>
              <p className="text-sm mt-1">A historical presentation website</p>
            </div>
            <nav>
              <ul className="flex flex-wrap justify-center gap-4">
                <li>
                  <Link href="/" className="hover:underline">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/economic-development" className="hover:underline">
                    Economic Development
                  </Link>
                </li>
                <li>
                  <Link href="/cultural-exchange" className="hover:underline">
                    Cultural Exchange
                  </Link>
                </li>
                <li>
                  <Link href="/colonialism-politics" className="hover:underline">
                    Colonialism & Politics
                  </Link>
                </li>
                <li>
                  <Link href="/legacy-settlement" className="hover:underline">
                    Legacy & Settlement
                  </Link>
                </li>
                <li>
                  <Link href="/sources" className="hover:underline">
                    Sources
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
          <div className="mt-6 text-center text-sm">
            <p>© {new Date().getFullYear()} Historical Presentation Project</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
