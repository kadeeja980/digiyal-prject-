import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function ColonialismPolitics() {
  return (
    <div className="min-h-screen bg-[#f5f2e8]">
      <div className="relative h-[40vh] w-full">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-AzfkYDmeRcNO5zs8FjOWZFYDp3Akgw.png"
          alt="Historical Research and Analysis"
          fill
          className="object-cover brightness-75"
          priority
        />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
          <h1 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 tracking-tight">
            Colonialism & Politics
          </h1>
          <p className="text-lg md:text-xl font-serif text-white max-w-3xl">
            From British Outpost to American Territory
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-12">
        <Link href="/" className="inline-flex items-center text-[#5d4037] hover:text-[#3e2723] mb-8 transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        <div className="max-w-4xl mx-auto">
          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              British Colonial Presence
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                Fort Vancouver represented the physical manifestation of British colonial ambitions in the Pacific
                Northwest. As the administrative headquarters of the Hudson's Bay Company's Columbia Department, the
                fort served as the center of British influence in a region claimed by both Great Britain and the United
                States creating ongoing diplomatic tensions.
              </p>

              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-IkR22CWKvzixjeac2wbJmsm9zFMQSj.png"
                  alt="Classical Government Building Representing Colonial Authority"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>

              <p>
                Under the leadership of Chief Factor Dr. John McLoughlin, the fort implemented British colonial policies
                while adapting to local conditions. The Hudson's Bay Company operated with a royal charter that granted
                governmental powers, including the authority to administer justice and manage relations with Indigenous
                peoples on behalf of the British Crown.
              </p>
              <p>
                The fort's imposing stockade, formal gardens, and European architectural elements was designed to
                project British power and civilization in what colonial authorities perceived as wilderness frontier.
                These physical manifestations of colonial authority formed part of Britain's strategy to strengthen its
                territorial claims to the Oregon Country.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              The Oregon Question
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                Fort Vancouver occupied a central position in the diplomatic dispute known as the "Oregon Question,"
                which concerned competing British and American claims to the Pacific Northwest. The region had been
                under joint British-American occupation since the Convention of 1818, but increasing American settlement
                in the 1840s intensified the territorial dispute.
              </p>

              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-f1apoZcd9H2wxmVlWPK1KP2vmZ0FiK.png"
                  alt="Historical Diplomatic Document with Official Seals"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>

              <p>
                The Hudson's Bay Company implemented a policy of creating a "fur desert" south of the Columbia River by
                aggressively trapping beaver to depletion. This strategy aimed to make the area less attractive to
                American trappers and settlers while maintaining British control north of the river.
              </p>
              <p>
                Despite these efforts American settlers began arriving in substantial numbers via the Oregon Trail
                during the early 1840s. Many were attracted by reports of the region's agricultural potential, which had
                been demonstrated through Fort Vancouver's successful farming operations. Dr. John McLoughlin often
                provided humanitarian assistance to these American immigrants, despite their presence threatening
                British territorial interests.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Transition to American Control
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                The Oregon Treaty of 1846 established the 49th parallel as the boundary between British and American
                territories, placing Fort Vancouver within United States jurisdiction. This diplomatic resolution
                avoided military conflict but fundamentally altered the fort's position and purpose within the regional
                power structure.
              </p>

              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-2A7XpvPW2THsQhKkBx65WBfm8wB4aM.png"
                  alt="Symbol of Governmental Authority and Sovereignty"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>

              <p>
                The Hudson's Bay Company continued operating at Fort Vancouver under special treaty provisions, but it's
                influence declined as American settlement increased throughout the region. In 1849, the U.S. Army
                established Columbia Barracks (later renamed Vancouver Barracks) adjacent to the fort, symbolizing the
                transition to American military and political control.
              </p>
              <p>
                By 1860, the Hudson's Bay Company had withdrawn from Fort Vancouver, ending its decades-long presence in
                the region. The forts buildings deteriorated or were repurposed, and the site was gradually absorbed
                into the growing American settlement of Vancouver. This transition represented the culmination of a
                significant shift in colonial power in the Pacific Northwest, from British commercial imperialism to
                American territorial expansion.
              </p>
            </div>
          </section>

          <div className="flex justify-between items-center mt-12 pt-6 border-t border-[#c9bda0]">
            <Link
              href="/cultural-exchange"
              className="text-[#5d4037] hover:text-[#3e2723] transition-colors flex items-center"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous: Cultural Exchange
            </Link>
            <Link
              href="/legacy-settlement"
              className="bg-[#5d4037] hover:bg-[#3e2723] text-white font-serif py-2 px-4 rounded-md transition-colors"
            >
              Next: Legacy & Settlement
            </Link>
          </div>
        </div>
      </main>

      <footer className="bg-[#3e2723] text-[#e8e1d1] py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-serif font-bold">Fort Vancouver: More Than a Fur Trading Post</h2>
              <p className="text-sm mt-1">A historical presentation website</p>
            </div>
            <nav>
              <ul className="flex flex-wrap justify-center gap-4">
                <li>
                  <Link href="/" className="hover:underline">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/economic-development" className="hover:underline">
                    Economic Development
                  </Link>
                </li>
                <li>
                  <Link href="/cultural-exchange" className="hover:underline">
                    Cultural Exchange
                  </Link>
                </li>
                <li>
                  <Link href="/colonialism-politics" className="hover:underline">
                    Colonialism & Politics
                  </Link>
                </li>
                <li>
                  <Link href="/legacy-settlement" className="hover:underline">
                    Legacy & Settlement
                  </Link>
                </li>
                <li>
                  <Link href="/sources" className="hover:underline">
                    Sources
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
          <div className="mt-6 text-center text-sm">
            <p>© {new Date().getFullYear()} Historical Presentation Project</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
