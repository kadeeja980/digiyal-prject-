import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function LegacySettlement() {
  return (
    <div className="min-h-screen bg-[#f5f2e8]">
      <div className="relative h-[40vh] w-full">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-pKzb53b79yO0BoPsLVJxqKNqziYYFZ.png"
          alt="Historical Navigation and Exploration"
          fill
          className="object-cover brightness-75"
          priority
        />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
          <h1 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 tracking-tight">
            Legacy & Settlement Patterns
          </h1>
          <p className="text-lg md:text-xl font-serif text-white max-w-3xl">Shaping the Modern Pacific Northwest</p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-12">
        <Link href="/" className="inline-flex items-center text-[#5d4037] hover:text-[#3e2723] mb-8 transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        <div className="max-w-4xl mx-auto">
          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Influence on Settlement Patterns
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                Fort Vancouver profoundly influenced settlement patterns throughout the Pacific Northwest. The fort's
                strategic location at the meeting point of the Columbia and Willamette Rivers established a focal point
                for regional development that continues to shape urban geography and transportation networks in the
                modern Pacific Northwest.
              </p>

              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2044&q=80"
                  alt="Early Settlement Patterns Around Fort Vancouver"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>

              <p>
                The fort's agricultural operations in the Willamette Valley encouraged early American settlement in that
                fertile region. Many retired Hudson's Bay Company employees established farms in the valley creating
                some of the earliest non-Indigenous settlements. The city of Portland, Oregon, developed at a site that
                had been identified by Fort Vancouver traders as an ideal location for settlement.
              </p>
              <p>
                The fort's extensive network of trails, trade routes, and supply lines established transportation
                corridors that later developed into major highways and railroad routes. Many modern cities in the
                Pacific Northwest, including Vancouver, Washington; Portland, Oregon; and Victoria, British Columbia,
                have direct connections to Hudson's Bay Company posts and the infrastructure they established.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Economic Legacy
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                Fort Vancouver's diverse economic activities established industries that became central to the Pacific
                Northwest economy for generations. The forts sawmill operation served as the precursor to the region's
                timber industry, which dominated the economies of Washington and Oregon well into the 20th century.
              </p>

              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80"
                  alt="Economic Legacy of Fort Vancouver"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>

              <p>
                The fort's agricultural experiments demonstrated the region's farming potential, leading to the
                development of wheat farming in eastern Washington and Oregon, fruit orchards in the Columbia River
                Valley, and diverse agriculture in the Willamette Valley. These agricultural patterns continue to define
                regional land use in the contemporary Pacific Northwest.
              </p>
              <p>
                The fort's role as a trading hub established the Pacific Northwest's orientation toward Pacific Rim
                trade. The connections to Hawaii, Russian Alaska, and Asian markets developed during the forts operation
                foreshadowed the region's modern economic ties to the Pacific economy and international trade networks.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Cultural and Social Legacy
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                The multicultural character of Fort Vancouver established patterns of diversity that continue to
                influence the Pacific Northwest. The region's early history of cultural exchange and intermarriage
                created communities with mixed European and Indigenous heritage throughout the territory, contributing
                to the regions distinctive cultural identity.
              </p>
              <p>
                Many prominent families in the Pacific Northwest trace their ancestry to fort employees and their
                Indigenous wives. These family networks created enduring connections between different cultural
                communities and influenced the development of regional identity and social structures.
              </p>
              <p>
                The fort's legacy is preserved today at Fort Vancouver National Historic Site, where archaeological
                research and historical interpretation continue to reveal the complex story of this influential
                settlement. The reconstructed fort serves as a reminder that Pacific Northwest history extends beyond
                American settlement encompassing diverse peoples and complex cultural exchanges that shaped the region's
                development.
              </p>
            </div>
          </section>

          <div className="flex justify-between items-center mt-12 pt-6 border-t border-[#c9bda0]">
            <Link
              href="/colonialism-politics"
              className="text-[#5d4037] hover:text-[#3e2723] transition-colors flex items-center"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous: Colonialism & Politics
            </Link>
            <Link
              href="/creative-feature"
              className="bg-[#5d4037] hover:bg-[#3e2723] text-white font-serif py-2 px-4 rounded-md transition-colors"
            >
              Next: Creative Feature
            </Link>
          </div>
        </div>
      </main>

      <footer className="bg-[#3e2723] text-[#e8e1d1] py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-serif font-bold">Fort Vancouver: More Than a Fur Trading Post</h2>
              <p className="text-sm mt-1">A historical presentation website</p>
            </div>
            <nav>
              <ul className="flex flex-wrap justify-center gap-4">
                <li>
                  <Link href="/" className="hover:underline">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/economic-development" className="hover:underline">
                    Economic Development
                  </Link>
                </li>
                <li>
                  <Link href="/cultural-exchange" className="hover:underline">
                    Cultural Exchange
                  </Link>
                </li>
                <li>
                  <Link href="/colonialism-politics" className="hover:underline">
                    Colonialism & Politics
                  </Link>
                </li>
                <li>
                  <Link href="/legacy-settlement" className="hover:underline">
                    Legacy & Settlement
                  </Link>
                </li>
                <li>
                  <Link href="/sources" className="hover:underline">
                    Sources
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
          <div className="mt-6 text-center text-sm">
            <p>© {new Date().getFullYear()} Historical Presentation Project</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
