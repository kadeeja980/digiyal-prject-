import type React from "react"
import type { Metadata } from "next"
import { Merriweather, Lora } from "next/font/google"
import "./globals.css"
import Navbar from "@/components/navbar"

const merriweather = Merriweather({
  weight: ["300", "400", "700", "900"],
  subsets: ["latin"],
  variable: "--font-merriweather",
  display: "swap",
})

const lora = Lora({
  subsets: ["latin"],
  variable: "--font-lora",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Fort Vancouver: More Than a Fur Trading Post",
  description:
    "Explore the broader historical impact of Fort Vancouver in the Pacific Northwest beyond its role as a fur trading post.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${merriweather.variable} ${lora.variable} font-sans`}>
        <Navbar />
        {children}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              // Disable right-click context menu
              document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
                return false;
              });

              // Disable common keyboard shortcuts
              document.addEventListener('keydown', function(e) {
                // Disable Ctrl+A (Select All)
                if (e.ctrlKey && e.keyCode === 65) {
                  e.preventDefault();
                  return false;
                }
                // Disable Ctrl+C (Copy)
                if (e.ctrlKey && e.keyCode === 67) {
                  e.preventDefault();
                  return false;
                }
                // Disable Ctrl+V (Paste)
                if (e.ctrlKey && e.keyCode === 86) {
                  e.preventDefault();
                  return false;
                }
                // Disable Ctrl+X (Cut)
                if (e.ctrlKey && e.keyCode === 88) {
                  e.preventDefault();
                  return false;
                }
                // Disable Ctrl+S (Save)
                if (e.ctrlKey && e.keyCode === 83) {
                  e.preventDefault();
                  return false;
                }
                // Disable Ctrl+U (View Source)
                if (e.ctrlKey && e.keyCode === 85) {
                  e.preventDefault();
                  return false;
                }
                // Disable F12 (Developer Tools)
                if (e.keyCode === 123) {
                  e.preventDefault();
                  return false;
                }
                // Disable Ctrl+Shift+I (Developer Tools)
                if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                  e.preventDefault();
                  return false;
                }
                // Disable Ctrl+Shift+J (Console)
                if (e.ctrlKey && e.shiftKey && e.keyCode === 74) {
                  e.preventDefault();
                  return false;
                }
                // Disable Ctrl+Shift+C (Inspect Element)
                if (e.ctrlKey && e.shiftKey && e.keyCode === 67) {
                  e.preventDefault();
                  return false;
                }
              });

              // Disable text selection with mouse
              document.addEventListener('selectstart', function(e) {
                e.preventDefault();
                return false;
              });

              // Disable drag and drop
              document.addEventListener('dragstart', function(e) {
                e.preventDefault();
                return false;
              });

              // Additional protection for images
              document.addEventListener('DOMContentLoaded', function() {
                const images = document.querySelectorAll('img');
                images.forEach(function(img) {
                  img.addEventListener('dragstart', function(e) {
                    e.preventDefault();
                    return false;
                  });
                });
              });

              // Disable print
              window.addEventListener('beforeprint', function(e) {
                e.preventDefault();
                return false;
              });
            `,
          }}
        />
      </body>
    </html>
  )
}
