import Link from "next/link"
import Image from "next/image"
import { ArrowLeft } from "lucide-react"

export default function CreativeFeature() {
  return (
    <div className="min-h-screen bg-[#f5f2e8]">
      <div className="relative h-[40vh] w-full">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-ThkSqqWjD02jCjuQYfCW173BxCqGOv.png"
          alt="Creative Writing and Storytelling"
          fill
          className="object-cover brightness-75"
          priority
        />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
          <h1 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 tracking-tight">Creative Feature</h1>
          <p className="text-lg md:text-xl font-serif text-white max-w-3xl">
            A Voice from the Past: Fictional Diary Entry
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-12">
        <Link href="/" className="inline-flex items-center text-[#5d4037] hover:text-[#3e2723] mb-8 transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        <div className="max-w-3xl mx-auto">
          <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg p-8 shadow-md mb-12">
            <div className="text-right mb-6 italic text-[#5d4037]">
              <p>Fort Vancouver</p>
              <p>September 22, 1843</p>
            </div>

            <div className="prose prose-lg max-w-none font-serif text-[#33272a] italic">
              <p>
                The autumn harvest proceeds with remarkable success. Our wheat fields have yielded over 4,000 bushels
                this season, far exceeding expectations when we first broke ground on these Columbia River plains. Dr.
                McLoughlin inspected the granaries yesterday and expressed satisfaction with our agricultural progress.
                The fort now sustains not only our own population of nearly 600 souls but produces surplus grain for
                export to the Russian settlements in Alaska and the Sandwich Islands.
              </p>

              <p>
                Today brought news from the Willamette Valley settlements. Another wagon train of American families
                arrived last week, swelling their numbers considerably. These emigrants speak boldly of their intention
                to claim the entire Oregon Country for the United States, despite our Company's long-established
                presence and the joint occupation agreement. Dr. McLoughlin continues his policy of providing
                humanitarian assistance to these settlers, though many among our officers question the wisdom of aiding
                those who may ultimately challenge British sovereignty in the region.
              </p>

              <p>
                The fort's sawmill operates at full capacity, producing timber for both local construction and export.
                Our Hawaiian laborers have proven invaluable in this enterprise, their experience with similar
                operations in the Islands serving us well. The lumber trade has become nearly as profitable as our
                traditional fur commerce, demonstrating the region's economic potential beyond the beaver trade that
                first brought us here.
              </p>

              <p>
                Chief Comcomly's son visited the fort this morning, accompanied by several Chinook traders bearing
                salmon and wapato roots. The salmon runs this year have been exceptional, and our preservation
                operations have produced sufficient stores for winter consumption and trade. The Chinook Jargon serves
                us well in these exchanges, though I observe the younger Indigenous traders increasingly incorporate
                English words into their speech.
              </p>

              <p>
                The cultural diversity of our community continues to fascinate visitors. At yesterday's evening meal, I
                counted representatives of at least eight different peoples: British officers, French-Canadian
                voyageurs, Métis families, Iroquois boatmen, Hawaiian laborers, local Indigenous peoples, and even a few
                American trappers who have taken employment with the Company. Each group maintains its distinct customs
                while contributing to our collective enterprise.
              </p>

              <p>
                Reports from London indicate growing political pressure regarding the Oregon boundary question. The
                Company directors express concern about American territorial ambitions and their potential impact on our
                operations. Yet here at Fort Vancouver, we continue our work of building a prosperous, multicultural
                community that demonstrates the possibilities of cooperation across cultural and national boundaries.
              </p>

              <p className="text-right mt-8">
                —Thomas McKay
                <br />
                Clerk & Trader, Hudson's Bay Company
              </p>
            </div>
          </div>

          <div className="bg-[#e8e1d1] border border-[#c9bda0] rounded-lg p-6 shadow-md">
            <h2 className="text-xl font-serif font-bold text-[#3e2723] mb-4">Historical Context</h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                This fictional diary entry reflects the historical realities of Fort Vancouver during the 1840s, drawing
                upon the key themes explored throughout this presentation. The entry incorporates several documented
                aspects of fort life:
              </p>
              <ul>
                <li>
                  <strong>Agricultural Development:</strong> Fort Vancouver's extensive farming operations, including
                  wheat cultivation that produced thousands of bushels annually and supported both local consumption and
                  export trade
                </li>
                <li>
                  <strong>Economic Diversification:</strong> The fort's evolution beyond fur trading to include lumber
                  production, salmon processing, and agricultural exports to Russian Alaska and Hawaii
                </li>
                <li>
                  <strong>Cultural Exchange:</strong> The multicultural composition of the fort community, including
                  British, French-Canadian, Hawaiian, Indigenous, Métis, and American residents working together
                </li>
                <li>
                  <strong>Political Tensions:</strong> The growing American settlement in the Willamette Valley and
                  increasing pressure on the joint occupation agreement between Britain and the United States
                </li>
                <li>
                  <strong>Indigenous Relations:</strong> Ongoing trade relationships with local tribes, particularly the
                  Chinook peoples, and the use of Chinook Jargon as a trade language
                </li>
                <li>
                  <strong>Colonial Dynamics:</strong> Dr. McLoughlin's humanitarian policies toward American settlers
                  despite their potential threat to British territorial claims
                </li>
              </ul>
              <p>
                While fictional, this diary entry aims to capture the complex economic, cultural, and political
                realities that made Fort Vancouver far more than a simple fur trading post, illustrating its role as a
                transformative force in Pacific Northwest development.
              </p>
            </div>
          </div>

          <div className="flex justify-between items-center mt-12 pt-6 border-t border-[#c9bda0]">
            <Link
              href="/legacy-settlement"
              className="text-[#5d4037] hover:text-[#3e2723] transition-colors flex items-center"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous: Legacy & Settlement
            </Link>
            <Link
              href="/sources"
              className="bg-[#5d4037] hover:bg-[#3e2723] text-white font-serif py-2 px-4 rounded-md transition-colors"
            >
              Next: Sources
            </Link>
          </div>
        </div>
      </main>

      <footer className="bg-[#3e2723] text-[#e8e1d1] py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-serif font-bold">Fort Vancouver: More Than a Fur Trading Post</h2>
              <p className="text-sm mt-1">A historical presentation website</p>
            </div>
            <nav>
              <ul className="flex flex-wrap justify-center gap-4">
                <li>
                  <Link href="/" className="hover:underline">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/economic-development" className="hover:underline">
                    Economic Development
                  </Link>
                </li>
                <li>
                  <Link href="/cultural-exchange" className="hover:underline">
                    Cultural Exchange
                  </Link>
                </li>
                <li>
                  <Link href="/colonialism-politics" className="hover:underline">
                    Colonialism & Politics
                  </Link>
                </li>
                <li>
                  <Link href="/legacy-settlement" className="hover:underline">
                    Legacy & Settlement
                  </Link>
                </li>
                <li>
                  <Link href="/sources" className="hover:underline">
                    Sources
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
          <div className="mt-6 text-center text-sm">
            <p>© {new Date().getFullYear()} Historical Presentation Project</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
