import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function EconomicDevelopment() {
  return (
    <div className="min-h-screen bg-[#f5f2e8]">
      <div className="relative h-[40vh] w-full">
        <Image
          src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2064&q=80"
          alt="Fort Vancouver Economic Development"
          fill
          className="object-cover brightness-75"
          priority
        />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
          <h1 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 tracking-tight">
            Economic Development
          </h1>
          <p className="text-lg md:text-xl font-serif text-white max-w-3xl">
            Beyond Fur: Fort Vancouver's Agricultural and Commercial Legacy
          </p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-12">
        <Link href="/" className="inline-flex items-center text-[#5d4037] hover:text-[#3e2723] mb-8 transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        <div className="max-w-4xl mx-auto">
          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Agricultural Innovation
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                Fort Vancouver had more than 1,500 acres of farmland growing potatoes, oats, wheat, peas, and other
                crops. Some of the earliest fruit trees were also kept in orchards at the fort. These cultural
                advancements are what helped Fort Vancouver become self-sufficient and also generate a surplus of goods
                for trade.
              </p>
              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://images.unsplash.com/photo-1625246333195-78d9c38ad449?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                  alt="Fort Vancouver Farm Operations"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>
              <p>
                This agricultural development displayed the region's fertile potential, disproving the notion that the
                Pacific Northwest was only valued for fur. The farming techniques and practices developed at Fort
                Vancouver influenced and impacted American settlers who arrived later on over the Oregon Trail.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Supply Hub and Trade Networks
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                Additionally, Vancouver served as the Hudson's Bay Company's main supply hub in the Pacific Northwest.
                Ships from Boston, Hawaii, and London were regularly docked at its harbor, supplying manufactured
                commodities and exporting timber, furs, and agricultural products.
              </p>

              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2044&q=80"
                  alt="Historical Trade Routes Map"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>

              <p>
                Fort Vancouver's strategic position at the meeting point of maritime and overland trade routes
                established it as the economic center of the region. Supply brigades departed from the fort to serve
                Hudson's Bay Company posts throughout present-day Washington, Oregon, Idaho, and British Columbia. The
                forts industrial facilities, including blacksmith shops, sawmills, and tanneries, produced essential
                tools, lumber, and manufactured goods required throughout the company's territory.
              </p>
              <p>
                This extensive trade network established economic patterns that influenced regional development long
                after the decline of the fur trade. Many modern transportation corridors and urban centers in the
                Pacific Northwest traces their origins to the trade routes and supply chains established by Fort
                Vancouver.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Diversified Industries
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                As the fur trade declined during the 1830s and 1840s, Fort Vancouver adapted by developing diverse
                industries that would sustain its economic relevance. The fort's sawmill, established in 1828,
                represented the first such facility in the Pacific Northwest and initiated the regions significant
                timber industry. Lumber production at Fort Vancouver supplied both local needs and export markets,
                particularly Hawaii and other Pacific destinations.
              </p>
              <p>
                The fort also developed salmon fishing and processing operations, capitalizing on the abundant fish runs
                in the Columbia River. Salted salmon became an important export commodity to Hawaii and other markets
                establishing commercial fishing practices that would become fundamental to the Columbia River Basin's
                economy.
              </p>
              <p>
                These diversified economic activities demonstrated the region's potential beyond fur trading and
                established industries that remained central to the Pacific Northwest economy for subsequent
                generations. The fort's economic innovations provided a foundation for the region's long-term
                development and prosperity.
              </p>
            </div>
          </section>

          <div className="flex justify-between items-center mt-12 pt-6 border-t border-[#c9bda0]">
            <Link href="/" className="text-[#5d4037] hover:text-[#3e2723] transition-colors flex items-center">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Link>
            <Link
              href="/cultural-exchange"
              className="bg-[#5d4037] hover:bg-[#3e2723] text-white font-serif py-2 px-4 rounded-md transition-colors"
            >
              Next: Cultural Exchange
            </Link>
          </div>
        </div>
      </main>

      <footer className="bg-[#3e2723] text-[#e8e1d1] py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-serif font-bold">Fort Vancouver: More Than a Fur Trading Post</h2>
              <p className="text-sm mt-1">A historical presentation website</p>
            </div>
            <nav>
              <ul className="flex flex-wrap justify-center gap-4">
                <li>
                  <Link href="/" className="hover:underline">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/economic-development" className="hover:underline">
                    Economic Development
                  </Link>
                </li>
                <li>
                  <Link href="/cultural-exchange" className="hover:underline">
                    Cultural Exchange
                  </Link>
                </li>
                <li>
                  <Link href="/colonialism-politics" className="hover:underline">
                    Colonialism & Politics
                  </Link>
                </li>
                <li>
                  <Link href="/legacy-settlement" className="hover:underline">
                    Legacy & Settlement
                  </Link>
                </li>
                <li>
                  <Link href="/sources" className="hover:underline">
                    Sources
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
          <div className="mt-6 text-center text-sm">
            <p>© {new Date().getFullYear()} Historical Presentation Project</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
