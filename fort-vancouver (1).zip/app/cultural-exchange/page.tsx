import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function CulturalExchange() {
  return (
    <div className="min-h-screen bg-[#f5f2e8]">
      <div className="relative h-[40vh] w-full">
        <Image
          src="https://images.unsplash.com/photo-1529258283598-8d6fe60b27f4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2074&q=80"
          alt="Fort Vancouver Cultural Exchange"
          fill
          className="object-cover brightness-75"
          priority
        />
        <div className="absolute inset-0 bg-black/30" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
          <h1 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 tracking-tight">
            Cultural Exchange
          </h1>
          <p className="text-lg md:text-xl font-serif text-white max-w-3xl">A Crossroads of Peoples and Traditions</p>
        </div>
      </div>

      <main className="container mx-auto px-4 py-12">
        <Link href="/" className="inline-flex items-center text-[#5d4037] hover:text-[#3e2723] mb-8 transition-colors">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        <div className="max-w-4xl mx-auto">
          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Multicultural Community
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                Fort Vancouver represented one of the most diverse communities in North America during the early 19th
                century. The fort's workforce included British officers, French-Canadian voyageurs, Hawaiian Islanders
                (known as Kanakas), Iroquois and Métis from eastern Canada, and local Indigenous peoples from numerous
                tribal groups throughout the region.
              </p>

              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://images.unsplash.com/photo-1544027993-37dbfe43562a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                  alt="Diverse Group of People Coming Together"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>

              <p>
                This diverse population created a unique cultural environment where different languages, customs, and
                traditions intersected and influenced one another. The forts "Village" housed hundreds of employees and
                their families in a community that reflected this cultural diversity. French served as a lingua franca
                alongside English, Chinook Jargon (a trade language), and numerous Indigenous languages.
              </p>
              <p>
                The multicultural character of Fort Vancouver established patterns of cultural exchange and diversity
                that continued to influence Pacific Northwest development. This diversity challenged conventional
                narratives about the region's historical development and demonstrated alternative models of cultural
                coexistence.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Indigenous Relations and Trade
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                Fort Vancouver served as a major point of contact between European traders and the diverse Indigenous
                peoples of the Pacific Northwest. The fort maintained trading relationships with Chinookan peoples along
                the Columbia River, Kalapuya in the Willamette Valley, Cowlitz to the north and numerous other tribal
                groups throughout the region.
              </p>

              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                  alt="Historic Trading Post Landscape"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>

              <p>
                These trading relationships involved complex exchanges that extended beyond simple commodity trading.
                Indigenous peoples provided essential furs, food, geographical knowledge, and labor to the fort while
                gaining access to manufactured goods, metals, textiles, and other trade items. The exchange also
                included knowledge, technologies, and cultural practices between different groups.
              </p>
              <p>
                However, these relationships occurred within the broader context of colonialism and changing power
                dynamics. The fort's presence contributed to significant changes in Indigenous economies, settlement
                patterns, and political relationships. Additionally the fort became a vector for diseases that
                devastated many Indigenous communities, representing one of the tragic consequences of European contact.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#3e2723] mb-6 border-b-2 border-[#5d4037] pb-2">
              Intermarriage and Family Networks
            </h2>
            <div className="prose prose-lg max-w-none font-serif text-[#33272a]">
              <p>
                Marriage alliances between Hudson's Bay Company employees and Indigenous women created important social,
                economic, and diplomatic connections throughout the region. These marriages, conducted "à la façon du
                pays" (according to the custom of the country), represented common practice in the fur trade and
                established kinship networks that facilitated trade and cultural exchange.
              </p>

              <div className="mt-6 mb-10 relative h-80 md:h-96">
                <Image
                  src="https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2074&q=80"
                  alt="Earth and Global Connections"
                  fill
                  className="object-cover rounded-lg"
                />
              </div>

              <p>
                The children of these unions, often identified as Métis, grew up in Fort Vancouver's multicultural
                environment and frequently became important cultural intermediaries between different communities. Many
                prominent families throughout the Pacific Northwest trace their ancestry to marriages between fort
                employees and Indigenous women.
              </p>
              <p>
                These family connections created lasting legacies that transcended the forts commercial operations and
                established enduring multicultural communities throughout the region. They represent an important aspect
                of Pacific Northwest history that challenges simplified narratives of European conquest and settlement,
                demonstrating instead the complex interconnections that characterized the regions development.
              </p>
            </div>
          </section>

          <div className="flex justify-between items-center mt-12 pt-6 border-t border-[#c9bda0]">
            <Link
              href="/economic-development"
              className="text-[#5d4037] hover:text-[#3e2723] transition-colors flex items-center"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous: Economic Development
            </Link>
            <Link
              href="/colonialism-politics"
              className="bg-[#5d4037] hover:bg-[#3e2723] text-white font-serif py-2 px-4 rounded-md transition-colors"
            >
              Next: Colonialism & Politics
            </Link>
          </div>
        </div>
      </main>

      <footer className="bg-[#3e2723] text-[#e8e1d1] py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-xl font-serif font-bold">Fort Vancouver: More Than a Fur Trading Post</h2>
              <p className="text-sm mt-1">A historical presentation website</p>
            </div>
            <nav>
              <ul className="flex flex-wrap justify-center gap-4">
                <li>
                  <Link href="/" className="hover:underline">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/economic-development" className="hover:underline">
                    Economic Development
                  </Link>
                </li>
                <li>
                  <Link href="/cultural-exchange" className="hover:underline">
                    Cultural Exchange
                  </Link>
                </li>
                <li>
                  <Link href="/colonialism-politics" className="hover:underline">
                    Colonialism & Politics
                  </Link>
                </li>
                <li>
                  <Link href="/legacy-settlement" className="hover:underline">
                    Legacy & Settlement
                  </Link>
                </li>
                <li>
                  <Link href="/sources" className="hover:underline">
                    Sources
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
          <div className="mt-6 text-center text-sm">
            <p>© {new Date().getFullYear()} Historical Presentation Project</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
