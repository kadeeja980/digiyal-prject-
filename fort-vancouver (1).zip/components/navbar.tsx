"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-[#5d4037] text-[#e8e1d1] sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="font-serif font-bold text-lg md:text-xl">
            Fort Vancouver
          </Link>

          {/* Mobile menu button */}
          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {/* Desktop navigation */}
          <nav className="hidden md:block">
            <ul className="flex space-x-6">
              <li>
                <Link href="/" className="hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/economic-development" className="hover:text-white transition-colors">
                  Economic Development
                </Link>
              </li>
              <li>
                <Link href="/cultural-exchange" className="hover:text-white transition-colors">
                  Cultural Exchange
                </Link>
              </li>
              <li>
                <Link href="/colonialism-politics" className="hover:text-white transition-colors">
                  Colonialism & Politics
                </Link>
              </li>
              <li>
                <Link href="/legacy-settlement" className="hover:text-white transition-colors">
                  Legacy & Settlement
                </Link>
              </li>
              <li>
                <Link href="/creative-feature" className="hover:text-white transition-colors">
                  Creative Feature
                </Link>
              </li>
              <li>
                <Link href="/sources" className="hover:text-white transition-colors">
                  Sources
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </div>

      {/* Mobile navigation */}
      {isMenuOpen && (
        <nav className="md:hidden bg-[#4e342e] pb-4">
          <ul className="flex flex-col space-y-2 px-4">
            <li>
              <Link
                href="/"
                className="block py-2 hover:text-white transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
            </li>
            <li>
              <Link
                href="/economic-development"
                className="block py-2 hover:text-white transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Economic Development
              </Link>
            </li>
            <li>
              <Link
                href="/cultural-exchange"
                className="block py-2 hover:text-white transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Cultural Exchange
              </Link>
            </li>
            <li>
              <Link
                href="/colonialism-politics"
                className="block py-2 hover:text-white transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Colonialism & Politics
              </Link>
            </li>
            <li>
              <Link
                href="/legacy-settlement"
                className="block py-2 hover:text-white transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Legacy & Settlement
              </Link>
            </li>
            <li>
              <Link
                href="/creative-feature"
                className="block py-2 hover:text-white transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Creative Feature
              </Link>
            </li>
            <li>
              <Link
                href="/sources"
                className="block py-2 hover:text-white transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Sources
              </Link>
            </li>
          </ul>
        </nav>
      )}
    </header>
  )
}
